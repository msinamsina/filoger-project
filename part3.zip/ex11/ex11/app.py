# Import necessary libraries for Flask and ML
from flask import Flask, render_template, request
import joblib
import numpy as np

# Initialize the Flask app
app = Flask(__name__)

# Load the trained machine learning model
model = joblib.load('model.pkl')

# Route for the home page
@app.route('/')
def home():
    return render_template('home.html')

# Route for the input form page
@app.route('/input')
def input_page():
    return render_template('input.html')

# Route to handle predictions
@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Get the data from the form (assuming 30 input features like in the breast cancer dataset)
        input_features = [float(x) for x in request.form.values()]
        input_array = np.array([input_features])

        # Make prediction
        prediction = model.predict(input_array)

        # Convert prediction to human-readable output
        result = "Cancerous" if prediction[0] == 1 else "Non-cancerous"

        # Render the result page with the prediction
        return render_template('result.html', prediction=result)

if __name__ == "__main__":
    app.run(debug=True)
